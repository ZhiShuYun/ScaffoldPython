# ZhiShuYun Scaffold

Install:

```
pip install "zhishuyun['scaffold']"
```

Sample:


```

```